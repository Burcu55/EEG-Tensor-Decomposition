# 🧠 Neural Tensor Analysis

This repository explores **tensor decomposition techniques** applied to neuroscience data, with a focus on EEG signals.  
The first example demonstrates **CP (Canonical Polyadic / PARAFAC) decomposition** on simulated EEG data using the `tensorly` Python library.

## 📊 Project Overview

Multidimensional datasets (e.g., EEG: channels × time × trials) are best analyzed using tensor methods. CP decomposition helps in:
- Reducing dimensionality
- Extracting latent components
- Enhancing interpretability of brain signals

## 📁 Files

| File                      | Description                                 |
|---------------------------|---------------------------------------------|
| `cp_decomposition_eeg.py` | Main script with CP decomposition on EEG    |
| `cp_decomposition_eeg.ipynb` | Jupyter notebook version                  |
| `requirements.txt`        | Required Python libraries                   |
| `README.md`               | This file                                   |

## ▶️ How to Run

### 1. Install dependencies:
```bash
pip install -r requirements.txt
```

### 2. Run the script:
```bash
python cp_decomposition_eeg.py
```

Or open the notebook:
```bash
jupyter notebook cp_decomposition_eeg.ipynb
```

## 🧪 Preview: Temporal Components

(Insert plot here if available)

## 🧠 Author

**Burcu Tutuk**  
PhD Candidate in Neuroscience  
Focus: EEG, Brain Signal Analysis, Machine Learning  
📧 burcuttk95@gmail.com

## 🔮 Next Steps

- Add real EEG dataset support using [MNE-Python](https://mne.tools)
- Try **Tucker decomposition** and **Non-negative Tensor Factorization (NTF)**
- Use on datasets like:
  - BCI Competition IV Dataset 2a
  - EPFL BCI Motor Imagery Dataset
  - HBN EEG (public)

## 📚 References

- Kolda & Bader (2009), *Tensor Decompositions and Applications*
- [TensorLy Documentation](https://tensorly.org/stable/)
- [MNE-Python](https://mne.tools/stable/index.html)