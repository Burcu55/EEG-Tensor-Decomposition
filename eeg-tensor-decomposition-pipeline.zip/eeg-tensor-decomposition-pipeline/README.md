# EEG Tensor Decomposition Pipeline

This repository demonstrates the use of tensor decomposition techniques (CP and Tucker) on real EEG data using Python. The project is structured into three parts:

### A. Tensor Decomposition on Real EEG Data
- Preprocessing EEG using MNE
- Creating a 3D tensor (channels × time × trials)
- Applying CP/Tucker decomposition

### B. Group-wise Comparison (e.g., ASD vs Control)
- Comparing tensor components between two groups

### C. Classification Using Tensor Features
- Extracting features from tensor decomposition
- Training classifiers (e.g., SVM, Logistic Regression)

---

Dependencies:
```bash
pip install -r requirements.txt
```

---

Burcu Tutuk, 2025 🧠